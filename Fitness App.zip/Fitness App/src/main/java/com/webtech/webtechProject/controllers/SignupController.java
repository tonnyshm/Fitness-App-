package com.webtech.webtechProject.controllers;


import com.webtech.webtechProject.model.Trainer;
import com.webtech.webtechProject.repository.TrainerRepository;
import com.webtech.webtechProject.services.SignupService;
import com.webtech.webtechProject.model.User;
import com.webtech.webtechProject.services.TrainerService;
import com.webtech.webtechProject.services.TrainerServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.Principal;

@Controller
public class SignupController {

    private final SignupService signupService;

    @Autowired
    private TrainerService trainerService;


    @Autowired
    public SignupController(SignupService signupService) {
        this.signupService = signupService;

    }

    @GetMapping("/signup")
    public String showSignupForm(Model model) {
        model.addAttribute("user", new User());
        return "signup";
    }


    @PostMapping("/signup")
    public String processSignupForm(@ModelAttribute("user")  User user, BindingResult result
                                    ) throws IOException {
       // userValidator.validate(user, result);
        if (result.hasErrors()) {
            return "signup";
        }
        signupService.saveUser(user);
        return "redirect:/login";
    }






    @PostMapping("/register")
    public String registerTrainer(@ModelAttribute("trainer") Trainer trainers) throws IOException {
        trainerService.save( trainers);
        return "redirect:/diet";
    }


    @GetMapping("/trainer")
    public String showTrainerSignupForm(Model model) {
        model.addAttribute("trainer", new Trainer());
        return "trainer";
    }


}


