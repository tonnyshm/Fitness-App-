package com.webtech.webtechProject.services;

import com.webtech.webtechProject.model.Trainer;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface TrainerService {

    void save( Trainer trainer) throws IOException;

}
