package com.webtech.webtechProject.model;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Data
public class Trainer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    private String  email;
    private String  password;
    private String contentType;

    @Enumerated(EnumType.STRING)
    private Gender gender;

    private int yearsOfExperience;

}
