package com.webtech.webtechProject.model;

public enum Gender {

    Female,
    Male

}
