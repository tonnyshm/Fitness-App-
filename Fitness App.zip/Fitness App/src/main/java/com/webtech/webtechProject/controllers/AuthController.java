package com.webtech.webtechProject.controllers;

import com.webtech.webtechProject.model.Trainer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AuthController {

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @GetMapping("/login/success")
    public String showLoginSuccess(Model model) {
        model.addAttribute("message", "Authentication successful!");
        return "trainer";
    }


    @GetMapping("/trainerLogin")
    public String showTrainerRegistrationForm(Model model) {
        model.addAttribute("trainer", new Trainer());
        return "trainerLogin";
    }


    @GetMapping("/trainerlogin")
    public String showTrainerLoginForm() {
        return "diet";
    }



}
