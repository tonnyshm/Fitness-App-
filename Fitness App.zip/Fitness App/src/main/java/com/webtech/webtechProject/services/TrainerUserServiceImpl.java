package com.webtech.webtechProject.services;

import com.webtech.webtechProject.model.Trainer;
import com.webtech.webtechProject.repository.TrainerRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class TrainerUserServiceImpl implements TrainerUserService {

    private final Logger logger = LoggerFactory.getLogger(UsersDetailsServicesImpl.class);

    @Autowired
    private TrainerRepository trainerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Trainer trainer = trainerRepository.findByUsername(username);
        if (trainer == null) {
            throw new UsernameNotFoundException("User not found");
        }
        return new TainerCustomUserDetails(trainer);
    }

    public Trainer findByUsername(String username) {
        return trainerRepository.findByUsername(username);
    }

    public Trainer getCurrentUser() {
        // Get the Authentication object from the SecurityContextHolder
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null) {
            Object principal = authentication.getPrincipal();

            // Check if the principal is a UserDetails object
            if (principal instanceof UserDetails) {
                UserDetails userDetails = (UserDetails) principal;

                // Find the user in the database based on the username
                return trainerRepository.findByUsername(userDetails.getUsername());
            }
        }

        return null;
    }

    public Trainer getUserByUsername(String username) {
        return trainerRepository.findByUsername(username);
    }

}


