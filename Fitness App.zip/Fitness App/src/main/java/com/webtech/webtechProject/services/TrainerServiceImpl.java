package com.webtech.webtechProject.services;

import com.webtech.webtechProject.model.Trainer;
import com.webtech.webtechProject.repository.TrainerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class TrainerServiceImpl implements TrainerService {

    @Autowired
    TrainerRepository trainerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void save( Trainer trainer) throws IOException {
        trainer.setPassword(passwordEncoder.encode(trainer.getPassword()));
        trainerRepository.save(trainer);
    }
}

