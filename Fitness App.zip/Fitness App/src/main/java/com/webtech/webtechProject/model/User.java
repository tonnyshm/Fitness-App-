package com.webtech.webtechProject.model;

import lombok.Data;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import javax.persistence.*;


@Data
@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String Email;
    private  String username;
    private String password;

    @ManyToOne
    private Trainer trainer;



}
