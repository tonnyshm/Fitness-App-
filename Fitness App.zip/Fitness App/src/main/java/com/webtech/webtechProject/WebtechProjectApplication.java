package com.webtech.webtechProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebtechProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebtechProjectApplication.class, args);
	}

}
