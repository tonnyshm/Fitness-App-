package com.webtech.webtechProject.services;

import com.webtech.webtechProject.model.User;


import java.io.IOException;

public interface SignupService {

    void saveUser(User user) throws IOException;
}
